from .mainInterface import init_mainInterface_routes

def init_routes(app):
    init_mainInterface_routes(app)