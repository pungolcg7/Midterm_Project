import { createApp } from 'src';
import App from './App.vue';

createApp(App).mount('#app');
