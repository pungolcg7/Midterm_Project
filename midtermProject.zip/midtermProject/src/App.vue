<template>
  <div id="app">
    <h1>Product Management</h1>
    <Products />
  </div>
</template>

<script>
import Products from './components/Products.vue';

export default {
  components: {
    Products
  }
};
</script>